import os
from datetime import date, datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

ROOT=os.path.abspath(os.path.dirname(__file__))
UPLOAD=os.path.join(ROOT,'uploads'); os.makedirs(UPLOAD,exist_ok=True)
app=Flask(__name__)
app.config['SECRET_KEY']=os.getenv('SECRET_KEY','troque-esta-chave-antes-de-publicar')
uri=os.getenv('DATABASE_URL','sqlite:///'+os.path.join(ROOT,'rihanna_juris.db'))
if uri.startswith('postgres://'): uri=uri.replace('postgres://','postgresql://',1)
app.config['SQLALCHEMY_DATABASE_URI']=uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['UPLOAD_FOLDER']=UPLOAD; app.config['MAX_CONTENT_LENGTH']=16*1024*1024
db=SQLAlchemy(app); lm=LoginManager(app); lm.login_view='login'; lm.login_message='Faça login para acessar o sistema.'

class User(UserMixin,db.Model):
 id=db.Column(db.Integer,primary_key=True); username=db.Column(db.String(80),unique=True,nullable=False); password_hash=db.Column(db.String(255),nullable=False)
 def set_password(self,p): self.password_hash=generate_password_hash(p)
 def check_password(self,p): return check_password_hash(self.password_hash,p)
class Client(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(160),nullable=False); document=db.Column(db.String(40),default=''); email=db.Column(db.String(160),default=''); phone=db.Column(db.String(40),default=''); address=db.Column(db.String(240),default=''); notes=db.Column(db.Text,default='')
class LegalCase(db.Model):
 id=db.Column(db.Integer,primary_key=True); case_number=db.Column(db.String(100),nullable=False); title=db.Column(db.String(180),nullable=False); area=db.Column(db.String(80),default='Cível'); court=db.Column(db.String(180),default=''); status=db.Column(db.String(40),default='Em andamento'); client_id=db.Column(db.Integer,db.ForeignKey('client.id')); client=db.relationship('Client',backref='cases'); description=db.Column(db.Text,default='')
class Deadline(db.Model):
 id=db.Column(db.Integer,primary_key=True); title=db.Column(db.String(180),nullable=False); due_date=db.Column(db.Date,nullable=False); priority=db.Column(db.String(30),default='Média'); status=db.Column(db.String(30),default='Pendente'); case_id=db.Column(db.Integer,db.ForeignKey('legal_case.id')); legal_case=db.relationship('LegalCase',backref='deadlines'); notes=db.Column(db.Text,default='')
class Hearing(db.Model):
 id=db.Column(db.Integer,primary_key=True); title=db.Column(db.String(180),nullable=False); hearing_date=db.Column(db.DateTime,nullable=False); location=db.Column(db.String(180),default=''); status=db.Column(db.String(30),default='Agendada'); case_id=db.Column(db.Integer,db.ForeignKey('legal_case.id')); legal_case=db.relationship('LegalCase',backref='hearings'); notes=db.Column(db.Text,default='')
class Fee(db.Model):
 id=db.Column(db.Integer,primary_key=True); description=db.Column(db.String(180),nullable=False); amount=db.Column(db.Float,nullable=False,default=0); paid=db.Column(db.Float,nullable=False,default=0); due_date=db.Column(db.Date); status=db.Column(db.String(30),default='Em aberto'); client_id=db.Column(db.Integer,db.ForeignKey('client.id')); client=db.relationship('Client',backref='fees'); case_id=db.Column(db.Integer,db.ForeignKey('legal_case.id')); legal_case=db.relationship('LegalCase',backref='fees'); notes=db.Column(db.Text,default='')
 @property
 def balance(self): return max(self.amount-self.paid,0)
class Document(db.Model):
 id=db.Column(db.Integer,primary_key=True); title=db.Column(db.String(180),nullable=False); filename=db.Column(db.String(255),nullable=False); original_name=db.Column(db.String(255),default=''); uploaded_at=db.Column(db.DateTime,default=datetime.utcnow); client_id=db.Column(db.Integer,db.ForeignKey('client.id')); client=db.relationship('Client',backref='documents'); case_id=db.Column(db.Integer,db.ForeignKey('legal_case.id')); legal_case=db.relationship('LegalCase',backref='documents')
@lm.user_loader
def load_user(uid): return db.session.get(User,int(uid))
@app.template_filter('brdate')
def brdate(v): return v.strftime('%d/%m/%Y') if v else '—'
@app.template_filter('brdatetime')
def brdatetime(v): return v.strftime('%d/%m/%Y às %H:%M') if v else '—'
@app.template_filter('brmoney')
def brmoney(v): return ('R$ {:,.2f}'.format(float(v or 0))).replace(',','X').replace('.',',').replace('X','.')
@app.context_processor
def globals_template(): return {'today':date.today()}
@app.route('/login',methods=['GET','POST'])
def login():
 if current_user.is_authenticated: return redirect(url_for('dashboard'))
 if request.method=='POST':
  u=User.query.filter_by(username=request.form.get('username','').strip()).first()
  if u and u.check_password(request.form.get('password','')): login_user(u); return redirect(request.args.get('next') or url_for('dashboard'))
  flash('Usuário ou senha incorretos.','danger')
 return render_template('login.html')
@app.route('/logout')
@login_required
def logout(): logout_user(); return redirect(url_for('login'))
@app.route('/')
@login_required
def dashboard():
 deadlines=Deadline.query.filter_by(status='Pendente').order_by(Deadline.due_date).limit(5).all()
 hearings=Hearing.query.filter(Hearing.hearing_date>=datetime.now()).order_by(Hearing.hearing_date).limit(5).all()
 return render_template('dashboard.html',clients=Client.query.count(),cases=LegalCase.query.count(),open_cases=LegalCase.query.filter_by(status='Em andamento').count(),deadlines=deadlines,hearings=hearings,balance=sum(x.balance for x in Fee.query.all()))

def save_record(obj, fields, required=()):
 for field in fields:
  value=request.form.get(field,'').strip()
  if field in ('client_id','case_id'): value=int(value) if value else None
  elif field in ('due_date',): value=date.fromisoformat(value) if value else None
  elif field=='hearing_date': value=datetime.fromisoformat(value) if value else None
  elif field in ('amount','paid'): value=float(value.replace(',','.')) if value else 0
  setattr(obj,field,value)
 for field in required:
  if not getattr(obj,field): raise ValueError('Preencha os campos obrigatórios.')
 db.session.add(obj); db.session.commit()

@app.route('/clientes')
@login_required
def clients():
 q=request.args.get('q','').strip(); query=Client.query
 if q: query=query.filter(Client.name.ilike(f'%{q}%'))
 return render_template('list.html',kind='clients',title='Clientes',items=query.order_by(Client.name).all(),q=q)
@app.route('/clientes/novo',methods=['GET','POST'])
@app.route('/clientes/<int:rid>/editar',methods=['GET','POST'])
@login_required
def client_form(rid=None):
 obj=db.session.get(Client,rid) if rid else Client()
 if rid and not obj: abort(404)
 fields=['name','document','email','phone','address','notes']
 if request.method=='POST':
  try: save_record(obj,fields,('name',)); flash('Cliente salvo com sucesso.','success'); return redirect(url_for('clients'))
  except ValueError as e: flash(str(e),'danger')
 return render_template('form.html',kind='clients',title='Editar cliente' if rid else 'Novo cliente',obj=obj,clients=Client.query.all(),cases=LegalCase.query.all())
@app.post('/clientes/<int:rid>/excluir')
@login_required
def client_delete(rid):
 o=db.session.get(Client,rid) or abort(404)
 if o.cases or o.fees or o.documents: flash('Não é possível excluir cliente vinculado a outros registros.','warning')
 else: db.session.delete(o); db.session.commit(); flash('Cliente excluído.','success')
 return redirect(url_for('clients'))

@app.route('/processos')
@login_required
def cases():
 q=request.args.get('q','').strip(); query=LegalCase.query
 if q: query=query.filter(db.or_(LegalCase.title.ilike(f'%{q}%'),LegalCase.case_number.ilike(f'%{q}%')))
 return render_template('list.html',kind='cases',title='Processos',items=query.order_by(LegalCase.id.desc()).all(),q=q)
@app.route('/processos/novo',methods=['GET','POST'])
@app.route('/processos/<int:rid>/editar',methods=['GET','POST'])
@login_required
def case_form(rid=None):
 obj=db.session.get(LegalCase,rid) if rid else LegalCase()
 if rid and not obj: abort(404)
 fields=['case_number','title','client_id','area','court','status','description']
 if request.method=='POST':
  try: save_record(obj,fields,('case_number','title')); flash('Processo salvo.','success'); return redirect(url_for('cases'))
  except ValueError as e: flash(str(e),'danger')
 return render_template('form.html',kind='cases',title='Editar processo' if rid else 'Novo processo',obj=obj,clients=Client.query.all(),cases=LegalCase.query.all())
@app.post('/processos/<int:rid>/excluir')
@login_required
def case_delete(rid):
 o=db.session.get(LegalCase,rid) or abort(404)
 for rel in [o.deadlines,o.hearings,o.fees,o.documents]:
  for x in rel: x.case_id=None
 db.session.delete(o); db.session.commit(); flash('Processo excluído; registros relacionados foram mantidos.','success'); return redirect(url_for('cases'))

@app.route('/prazos')
@login_required
def deadlines(): return render_template('list.html',kind='deadlines',title='Prazos',items=Deadline.query.order_by(Deadline.due_date).all(),q='')
@app.route('/prazos/novo',methods=['GET','POST'])
@app.route('/prazos/<int:rid>/editar',methods=['GET','POST'])
@login_required
def deadline_form(rid=None):
 obj=db.session.get(Deadline,rid) if rid else Deadline()
 if rid and not obj: abort(404)
 fields=['title','due_date','priority','status','case_id','notes']
 if request.method=='POST':
  try: save_record(obj,fields,('title','due_date')); flash('Prazo salvo.','success'); return redirect(url_for('deadlines'))
  except (ValueError,TypeError) as e: flash('Confira o título e a data do prazo.','danger')
 return render_template('form.html',kind='deadlines',title='Editar prazo' if rid else 'Novo prazo',obj=obj,clients=Client.query.all(),cases=LegalCase.query.all())
@app.post('/prazos/<int:rid>/concluir')
@login_required
def deadline_done(rid):
 o=db.session.get(Deadline,rid) or abort(404); o.status='Concluído'; db.session.commit(); flash('Prazo concluído.','success'); return redirect(url_for('deadlines'))
@app.post('/prazos/<int:rid>/excluir')
@login_required
def deadline_delete(rid):
 o=db.session.get(Deadline,rid) or abort(404); db.session.delete(o); db.session.commit(); flash('Prazo excluído.','success'); return redirect(url_for('deadlines'))

@app.route('/audiencias')
@login_required
def hearings(): return render_template('list.html',kind='hearings',title='Audiências',items=Hearing.query.order_by(Hearing.hearing_date).all(),q='')
@app.route('/audiencias/nova',methods=['GET','POST'])
@app.route('/audiencias/<int:rid>/editar',methods=['GET','POST'])
@login_required
def hearing_form(rid=None):
 obj=db.session.get(Hearing,rid) if rid else Hearing()
 if rid and not obj: abort(404)
 fields=['title','hearing_date','location','status','case_id','notes']
 if request.method=='POST':
  try: save_record(obj,fields,('title','hearing_date')); flash('Audiência salva.','success'); return redirect(url_for('hearings'))
  except (ValueError,TypeError): flash('Confira o título, data e horário.','danger')
 return render_template('form.html',kind='hearings',title='Editar audiência' if rid else 'Nova audiência',obj=obj,clients=Client.query.all(),cases=LegalCase.query.all())
@app.post('/audiencias/<int:rid>/excluir')
@login_required
def hearing_delete(rid):
 o=db.session.get(Hearing,rid) or abort(404); db.session.delete(o); db.session.commit(); flash('Audiência excluída.','success'); return redirect(url_for('hearings'))

@app.route('/financeiro')
@login_required
def fees(): return render_template('list.html',kind='fees',title='Financeiro',items=Fee.query.order_by(Fee.due_date).all(),q='')
@app.route('/financeiro/novo',methods=['GET','POST'])
@app.route('/financeiro/<int:rid>/editar',methods=['GET','POST'])
@login_required
def fee_form(rid=None):
 obj=db.session.get(Fee,rid) if rid else Fee()
 if rid and not obj: abort(404)
 fields=['description','amount','paid','due_date','client_id','case_id','notes']
 if request.method=='POST':
  try:
   save_record(obj,fields,('description',)); obj.status='Pago' if obj.paid>=obj.amount else ('Parcial' if obj.paid>0 else 'Em aberto'); db.session.commit(); flash('Lançamento salvo.','success'); return redirect(url_for('fees'))
  except (ValueError,TypeError): flash('Confira a descrição, valores e data.','danger')
 return render_template('form.html',kind='fees',title='Editar lançamento' if rid else 'Novo lançamento',obj=obj,clients=Client.query.all(),cases=LegalCase.query.all())
@app.post('/financeiro/<int:rid>/excluir')
@login_required
def fee_delete(rid):
 o=db.session.get(Fee,rid) or abort(404); db.session.delete(o); db.session.commit(); flash('Lançamento excluído.','success'); return redirect(url_for('fees'))

@app.route('/documentos',methods=['GET','POST'])
@login_required
def documents():
 if request.method=='POST':
  f=request.files.get('file'); title=request.form.get('title','').strip()
  allowed={'pdf','doc','docx','png','jpg','jpeg','txt'}
  if not f or not f.filename: flash('Selecione um arquivo.','danger')
  elif '.' not in f.filename or f.filename.rsplit('.',1)[1].lower() not in allowed: flash('Tipo não permitido. Use PDF, DOC, DOCX, PNG, JPG ou TXT.','danger')
  else:
   original=f.filename; safe=secure_filename(original); stored=datetime.utcnow().strftime('%Y%m%d%H%M%S%f')+'_'+safe; f.save(os.path.join(UPLOAD,stored))
   d=Document(title=title or original,filename=stored,original_name=original,client_id=int(request.form['client_id']) if request.form.get('client_id') else None,case_id=int(request.form['case_id']) if request.form.get('case_id') else None); db.session.add(d); db.session.commit(); flash('Documento enviado.','success'); return redirect(url_for('documents'))
 return render_template('list.html',kind='documents',title='Documentos',items=Document.query.order_by(Document.uploaded_at.desc()).all(),q='',clients=Client.query.all(),cases=LegalCase.query.all())
@app.route('/documentos/<int:rid>/baixar')
@login_required
def document_download(rid):
 d=db.session.get(Document,rid) or abort(404); return send_from_directory(UPLOAD,d.filename,as_attachment=True,download_name=d.original_name or d.filename)
@app.post('/documentos/<int:rid>/excluir')
@login_required
def document_delete(rid):
 d=db.session.get(Document,rid) or abort(404); p=os.path.join(UPLOAD,d.filename)
 if os.path.exists(p): os.remove(p)
 db.session.delete(d); db.session.commit(); flash('Documento excluído.','success'); return redirect(url_for('documents'))
@app.errorhandler(413)
def too_large(e): flash('Arquivo muito grande. Limite de 16 MB.','danger'); return redirect(url_for('documents'))
with app.app_context():
 db.create_all()
 if not User.query.first():
  u=User(username=os.getenv('ADMIN_USERNAME','admin')); u.set_password(os.getenv('ADMIN_PASSWORD','Admin@12345')); db.session.add(u); db.session.commit()
if __name__=='__main__': app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=os.getenv('FLASK_DEBUG')=='1')
